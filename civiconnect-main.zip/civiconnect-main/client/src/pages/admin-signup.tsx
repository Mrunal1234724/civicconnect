import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import OTPInput from "@/components/ui/otp-input";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { sendOTP, verifyOTP } from "@/lib/auth";
import { Loader2, ShieldQuestion, Phone } from "lucide-react";

const adminSignupSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Phone number must be at least 10 digits"),
  employeeId: z.string().min(3, "Employee ID is required"),
  department: z.enum(["roads", "sanitation", "water", "animal-control"], {
    required_error: "Please select a department"
  }),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string()
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type AdminSignupFormData = z.infer<typeof adminSignupSchema>;

export default function AdminSignup() {
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<"form" | "otp">("form");
  const [otp, setOtp] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);
  const [formData, setFormData] = useState<AdminSignupFormData | null>(null);
  const [, setLocation] = useLocation();
  const { signup } = useAuth();
  const { toast } = useToast();

  const form = useForm<AdminSignupFormData>({
    resolver: zodResolver(adminSignupSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      employeeId: "",
      department: undefined,
      password: "",
      confirmPassword: ""
    }
  });

  const handleFormSubmit = async (data: AdminSignupFormData) => {
    setLoading(true);
    try {
      await sendOTP(data.phone);
      setFormData(data);
      setStep("otp");
      toast({
        title: "OTP Sent",
        description: "Please check your phone for the verification code.",
      });
    } catch (error) {
      console.error('Send OTP error:', error);
      toast({
        title: "Failed to Send OTP",
        description: "Please check your phone number and try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOTPSubmit = async () => {
    if (!formData || otp.length !== 6) return;

    setOtpLoading(true);
    try {
      await verifyOTP(formData.phone, otp);
      
      const signupData = {
        user: {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          password: formData.password
        },
        admin: {
          userId: "", // Will be set by backend
          employeeId: formData.employeeId,
          department: formData.department
        },
        otp: otp
      };

      await signup(signupData, true); // isAdmin = true
      
      toast({
        title: "Application Submitted!",
        description: "Your admin application has been submitted for approval. You will be notified once approved.",
      });
      setLocation("/admin/login");
    } catch (error) {
      console.error('Admin signup error:', error);
      toast({
        title: "Application Failed",
        description: error instanceof Error ? error.message : "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    } finally {
      setOtpLoading(false);
    }
  };

  const resendOTP = async () => {
    if (!formData) return;
    
    try {
      await sendOTP(formData.phone);
      toast({
        title: "OTP Resent",
        description: "A new verification code has been sent to your phone.",
      });
    } catch (error) {
      toast({
        title: "Failed to Resend OTP",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  };

  const departmentOptions = [
    { value: "roads", label: "Roads & Infrastructure" },
    { value: "sanitation", label: "Sanitation" },
    { value: "water", label: "Water Management" },
    { value: "animal-control", label: "Animal Control" }
  ];

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-md w-full">
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="text-secondary text-4xl mb-4 flex justify-center">
              <ShieldQuestion className="w-12 h-12" />
            </div>
            <CardTitle className="text-3xl font-bold text-card-foreground">
              Admin Registration
            </CardTitle>
            <p className="text-muted-foreground mt-2">
              Apply for administrative access
            </p>
          </CardHeader>
          <CardContent>
            {step === "form" ? (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your full name"
                            {...field}
                            data-testid="admin-name-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Official Email</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="Enter your official email"
                            {...field}
                            data-testid="admin-email-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mobile Number</FormLabel>
                        <FormControl>
                          <Input
                            type="tel"
                            placeholder="Enter your mobile number"
                            {...field}
                            data-testid="admin-phone-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="employeeId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Employee ID</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Enter your employee ID"
                            {...field}
                            data-testid="admin-employee-id-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="department"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Department</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="admin-department-select">
                              <SelectValue placeholder="Select your department" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {departmentOptions.map(option => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            placeholder="Create a password"
                            {...field}
                            data-testid="admin-password-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirm Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            placeholder="Confirm your password"
                            {...field}
                            data-testid="admin-confirm-password-input"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90" 
                    disabled={loading}
                    data-testid="admin-signup-submit-button"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending OTP...
                      </>
                    ) : (
                      <>
                        <Phone className="mr-2 h-4 w-4" />
                        Send Verification Code
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    Verify Mobile Number
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Enter the 6-digit code sent to {formData?.phone}
                  </p>
                </div>

                <div className="space-y-4">
                  <OTPInput
                    length={6}
                    value={otp}
                    onChange={setOtp}
                    onComplete={setOtp}
                    data-testid="admin-otp-verification-input"
                  />

                  <Button
                    onClick={handleOTPSubmit}
                    disabled={otp.length !== 6 || otpLoading}
                    className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90"
                    data-testid="admin-verify-otp-button"
                  >
                    {otpLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Submitting Application...
                      </>
                    ) : (
                      <>
                        <ShieldQuestion className="mr-2 h-4 w-4" />
                        Submit Application
                      </>
                    )}
                  </Button>

                  <div className="text-center">
                    <Button 
                      type="button" 
                      variant="link" 
                      onClick={resendOTP}
                      className="text-sm"
                      data-testid="admin-resend-otp-button"
                    >
                      Didn't receive code? Resend
                    </Button>
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep("form")}
                    className="w-full"
                    data-testid="admin-back-to-form-button"
                  >
                    Back to Form
                  </Button>
                </div>
              </div>
            )}

            <div className="mt-6 text-center">
              <p className="text-muted-foreground">
                Already registered?{" "}
                <Link href="/admin/login">
                  <Button variant="link" className="px-0 text-secondary" data-testid="admin-login-link">
                    Sign In
                  </Button>
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
