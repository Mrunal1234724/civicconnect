import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";

import { Button } from "../components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../components/ui/form";
import { Input } from "../components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import OTPInput from "../components/ui/otp-input";

import { useToast } from "../hooks/use-toast";
import { sendOTP, verifyOTP, auth, initRecaptcha } from "../lib/auth";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";

import { Loader2, UserPlus, Smartphone } from "lucide-react";

// ✅ Validation schema
const signupSchema = z
  .object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    email: z.string().email("Invalid email address"),
    phone: z.string().min(10, "Enter a valid phone number"),
    password: z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type SignupFormData = z.infer<typeof signupSchema>;

export default function Signup() {
  const [step, setStep] = useState<"form" | "otp">("form");
  const [formData, setFormData] = useState<SignupFormData | null>(null);
  const [loading, setLoading] = useState(false);
  const [otp, setOtp] = useState("");
  const [otpLoading, setOtpLoading] = useState(false);

  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<SignupFormData>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: "",
    },
  });

  // ✅ Initialize reCAPTCHA when the component mounts
  useState(() => {
    setTimeout(() => {
      initRecaptcha();
    }, 500);
  });

  /**
   * 🔹 Step 1: Send OTP
   */
  const handleFormSubmit = async (data: SignupFormData) => {
    setLoading(true);
    try {
      const phoneWithCode = data.phone.startsWith("+") ? data.phone : `+91${data.phone}`;

      await sendOTP(phoneWithCode);
      setFormData(data);
      setStep("otp");

      toast({
        title: "OTP Sent ✅",
        description: `Verification code sent to ${phoneWithCode}`,
      });
    } catch (err: any) {
      console.error("OTP send error:", err);
      toast({
        title: "Failed to Send OTP ❌",
        description: err.message || "Unable to send OTP. Check Firebase setup.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  /**
   * 🔹 Step 2: Verify OTP + Create Account
   */
  const handleOTPSubmit = async () => {
    if (!formData || otp.length !== 6) return;

    setOtpLoading(true);
    try {
      await verifyOTP(otp);

      // ✅ Create user in Firebase
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);

      // ✅ Update profile with name & phone
      await updateProfile(userCredential.user, {
        displayName: formData.name,
      });

      toast({
        title: "Account Created 🎉",
        description: "Welcome to CivicConnect!",
      });

      setLocation("/");
    } catch (err: any) {
      console.error("Signup error:", err);
      toast({
        title: "Signup Failed ❌",
        description: err.message || "Invalid or expired OTP.",
        variant: "destructive",
      });
    } finally {
      setOtpLoading(false);
    }
  };

  /**
   * 🔁 Resend OTP
   */
  const resendOTP = async () => {
    if (!formData) return;
    try {
      const phoneWithCode = formData.phone.startsWith("+") ? formData.phone : `+91${formData.phone}`;
      await sendOTP(phoneWithCode);

      toast({
        title: "OTP Resent 🔁",
        description: `Verification code sent again to ${phoneWithCode}`,
      });
    } catch (err: any) {
      toast({
        title: "Failed to Resend OTP",
        description: err.message || "Could not resend OTP.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 bg-muted/30">
      <div className="max-w-md w-full">
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold">Create Account</CardTitle>
            <p className="text-muted-foreground mt-2">Join CivicConnect to start reporting issues</p>
          </CardHeader>

          <CardContent>
            {/* 🔹 reCAPTCHA Container */}
            <div id="recaptcha-container" className="my-4 flex justify-center"></div>

            {step === "form" ? (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
                  {["name", "email", "phone", "password", "confirmPassword"].map((field) => (
                    <FormField
                      key={field}
                      control={form.control}
                      name={field as any}
                      render={({ field: f }) => (
                        <FormItem>
                          <FormLabel>
                            {field === "confirmPassword"
                              ? "Confirm Password"
                              : field.charAt(0).toUpperCase() + field.slice(1)}
                          </FormLabel>
                          <FormControl>
                            <Input
                              {...f}
                              type={
                                field.includes("password")
                                  ? "password"
                                  : field === "email"
                                  ? "email"
                                  : "text"
                              }
                              placeholder={`Enter your ${field}`}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  ))}

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? (
                      <Loader2 className="animate-spin mr-2 h-4 w-4" />
                    ) : (
                      <Smartphone className="mr-2 h-4 w-4" />
                    )}
                    {loading ? "Sending OTP..." : "Send OTP"}
                  </Button>
                </form>
              </Form>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold">Verify Phone</h3>
                  <p>Enter the 6-digit code sent to {formData?.phone || "your phone"}</p>
                </div>

                <OTPInput length={6} value={otp} onChange={setOtp} onComplete={handleOTPSubmit} />

                <Button onClick={handleOTPSubmit} disabled={otp.length !== 6 || otpLoading} className="w-full">
                  {otpLoading ? (
                    <Loader2 className="animate-spin mr-2 h-4 w-4" />
                  ) : (
                    <UserPlus className="mr-2 h-4 w-4" />
                  )}
                  {otpLoading ? "Verifying..." : "Create Account"}
                </Button>

                <Button type="button" variant="link" onClick={resendOTP}>
                  Resend OTP
                </Button>
                <Button type="button" variant="outline" onClick={() => setStep("form")}>
                  Back to Form
                </Button>
              </div>
            )}

            <div className="mt-6 text-center">
              Already have an account?{" "}
              <Link href="/login">
                <Button variant="link">Sign In</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
