import { useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "../hooks/use-toast"; // reuse your toast hook
import { Loader2 } from "lucide-react";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      if (username.trim() === "mitali" && password.trim() === "mitali123") {
        localStorage.setItem("isAdmin", "true");
        toast({ title: "Login Successful", description: "Welcome Admin!" });
        setLocation("/admin/dashboard");
      } else {
        toast({ title: "Access Denied", description: "Invalid username or password", variant: "destructive" });
      }
      setLoading(false);
    }, 1000); // simulate loading
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <form
        onSubmit={handleLogin}
        className="bg-white p-6 rounded-lg shadow-md w-full max-w-sm"
      >
        <h2 className="text-2xl font-bold mb-4 text-center">Admin Login</h2>

        <div className="mb-4">
          <label className="block mb-1 font-medium">Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full border rounded px-3 py-2"
            placeholder="Enter admin username"
            required
          />
        </div>

        <div className="mb-4">
          <label className="block mb-1 font-medium">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border rounded px-3 py-2"
            placeholder="Enter admin password"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 flex items-center justify-center"
          disabled={loading}
        >
          {loading ? <Loader2 className="animate-spin h-5 w-5 mr-2" /> : null}
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>
    </div>
  );
}
