import React, { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { getUserComplaints, ComplaintData } from "@/lib/complaints";
import { Loader2 } from "lucide-react";

const Profile: React.FC = () => {
  const { user } = useAuth();
  const [complaints, setComplaints] = useState<ComplaintData[]>([]);
  const [loading, setLoading] = useState(true);

  // 🔹 Fetch complaints from backend
  const fetchComplaints = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const data = await getUserComplaints(); // typed as ComplaintData[]
      setComplaints(data);
    } catch (err) {
      console.error("Error fetching complaints:", err);
      setComplaints([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, [user]);

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <p className="text-xl font-semibold text-gray-700">
          Please log in to view your profile.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto mt-10 px-4">
      {/* Profile Card */}
      <div className="mb-6 p-6 bg-white shadow-lg rounded-lg border border-gray-200">
        <h2 className="text-3xl font-bold mb-4 text-gray-800">Profile</h2>
        <p className="text-lg text-gray-700 mb-2">
          <span className="font-semibold">Name:</span> {user.name}
        </p>
        <p className="text-lg text-gray-700">
          <span className="font-semibold">Email:</span> {user.email}
        </p>
      </div>

      {/* Complaints Section */}
      <h3 className="text-2xl font-semibold mb-4 text-gray-800">Your Complaints</h3>

      {loading ? (
        <div className="flex items-center justify-center">
          <Loader2 className="animate-spin mr-2" /> Loading complaints...
        </div>
      ) : complaints.length === 0 ? (
        <p className="text-gray-500">No complaints submitted yet.</p>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {complaints.map((c) => (
            <Card
              key={c._id || c.trackingId}
              className="shadow-md border rounded-lg hover:shadow-lg transition-all"
            >
              <CardHeader className="flex justify-between items-start">
                <CardTitle className="text-lg font-bold">{c.title || "Untitled Complaint"}</CardTitle>
                <Badge
                  variant={
                    c.status === "resolved"
                      ? "default"
                      : c.status === "pending"
                      ? "secondary"
                      : "outline"
                  }
                  className="ml-2"
                >
                  {c.status?.toUpperCase() || "PENDING"}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-gray-700">{c.description}</p>
                <p className="text-sm text-gray-500">Tracking ID: {c.trackingId || "-"}</p>
                <p className="text-sm text-gray-500">
                  Date: {c.createdAt ? new Date(c.createdAt).toLocaleString() : "-"}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Profile;
