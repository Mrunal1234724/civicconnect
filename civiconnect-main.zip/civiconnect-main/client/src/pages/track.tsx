import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { trackComplaint } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  MapPin, 
  Phone, 
  Calendar,
  Clock,
  AlertTriangle,
  Loader2
} from "lucide-react";
import { format } from "date-fns";

interface ComplaintData {
  id: string;
  trackingId: string;
  issueType: string;
  title: string;
  description: string;
  address: string;
  status: string;
  severityFinal: string;
  complainantName: string;
  complainantPhone: string;
  images: string[];
  createdAt: string;
  updatedAt: string;
}

interface UpdateData {
  id: string;
  newStatus: string;
  notes: string;
  createdAt: string;
}

export default function Track() {
  const [trackingId, setTrackingId] = useState("");
  const [searchId, setSearchId] = useState("");
  const { toast } = useToast();

  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/complaints/track', searchId],
    queryFn: () => trackComplaint(searchId),
    enabled: !!searchId,
  });

  const handleSearch = () => {
    if (!trackingId.trim()) {
      toast({
        title: "Tracking ID Required",
        description: "Please enter a valid tracking ID.",
        variant: "destructive",
      });
      return;
    }
    setSearchId(trackingId.trim());
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
      "in-progress": "bg-blue-100 text-blue-800 border-blue-200",
      resolved: "bg-green-100 text-green-800 border-green-200",
      rejected: "bg-red-100 text-red-800 border-red-200",
    } as const;

    return (
      <Badge 
        className={colors[status as keyof typeof colors] || colors.pending}
        data-testid={`status-badge-${status}`}
      >
        {status?.replace('-', ' ').toUpperCase()}
      </Badge>
    );
  };

  const getSeverityBadge = (severity: string) => {
    const normalizedSeverity = severity?.toLowerCase(); // normalize casing

    const colors = {
      high: "bg-red-100 text-red-800 border-red-200",
      medium: "bg-yellow-100 text-yellow-800 border-yellow-200", 
      low: "bg-green-100 text-green-800 border-green-200",
    } as const;

    return (
      <Badge 
        className={colors[normalizedSeverity as keyof typeof colors] || colors.medium}
        data-testid={`severity-badge-${normalizedSeverity}`}
      >
        {normalizedSeverity?.toUpperCase()}
      </Badge>
    );
  };

  const getIssueIcon = (issueType: string) => {
    const icons = {
      pothole: "🕳️",
      waterlogging: "💧",
      "stray-dogs": "🐕",
      "garbage-overflow": "🗑️",
    } as const;

    return icons[issueType as keyof typeof icons] || "📋";
  };

  // 🔑 FIX: adapt data from backend (flat or nested)
  let complaint: ComplaintData | undefined = undefined;
  let updates: UpdateData[] = [];

  if (data) {
    if (data.complaint) {
      // if backend returns { complaint, updates }
      complaint = data.complaint;
      updates = data.updates || [];
    } else {
      // if backend returns flat complaint object
      complaint = {
        id: data.trackingId,
        trackingId: data.trackingId,
        issueType: data.issueType || "general",
        title: data.title || "Complaint",
        description: data.description || "",
        address: data.address || "N/A",
        status: data.status,
        severityFinal: data.severity || data.severityFinal || "low",
        complainantName: data.complainantName || "N/A",
        complainantPhone: data.complainantPhone || "N/A",
        images: data.images || [],
        createdAt: data.createdAt,
        updatedAt: data.updatedAt || data.createdAt,
      };
      updates = [];
    }
  }

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-4xl mx-auto">
        {/* Search Section */}
        <Card className="mb-8 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-card-foreground">
              Track Your Complaint
            </CardTitle>
            <p className="text-muted-foreground mt-2">
              Enter your complaint ID to check status
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 max-w-md mx-auto">
              <div className="flex-1">
                <Label htmlFor="complaint-id" className="sr-only">Complaint ID</Label>
                <Input
                  id="complaint-id"
                  value={trackingId}
                  onChange={(e) => setTrackingId(e.target.value)}
                  placeholder="Enter Complaint ID (e.g., CC2024-001)"
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  data-testid="tracking-id-input"
                />
              </div>
              <Button 
                onClick={handleSearch}
                disabled={isLoading}
                data-testid="track-complaint-button"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Search className="w-4 h-4 mr-2" />
                )}
                Track
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Error State */}
        {error && (
          <Card className="mb-8">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-12 h-12 text-destructive mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Complaint Not Found</h3>
              <p className="text-muted-foreground">
                Please check your tracking ID and try again.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Complaint Details */}
        {complaint && (
          <Card className="shadow-xl">
            {/* Header */}
            <CardHeader className="border-b border-border">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <span className="text-2xl">{getIssueIcon(complaint.issueType)}</span>
                    Complaint #{complaint.trackingId}
                  </CardTitle>
                  <p className="text-muted-foreground capitalize mt-1">
                    {complaint.issueType.replace('-', ' ')} - {complaint.title}
                  </p>
                </div>
                {getStatusBadge(complaint.status)}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 text-sm">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Submitted:</span>
                  <span className="text-foreground">
                    {format(new Date(complaint.createdAt), 'MMM dd, yyyy')}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">Priority:</span>
                  {getSeverityBadge(complaint.severityFinal)}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">Last Updated:</span>
                  <span className="text-foreground">
                    {format(new Date(complaint.updatedAt), 'MMM dd, yyyy')}
                  </span>
                </div>
              </div>
            </CardHeader>

            <CardContent className="p-6">
              {/* Description */}
              <div className="mb-6">
                <h4 className="font-semibold text-foreground mb-2">Description</h4>
                <p className="text-muted-foreground">{complaint.description}</p>
              </div>

              {/* Progress Timeline */}
              <div className="mb-6">
                <h4 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Progress Timeline
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center gap-4" data-testid="timeline-submitted">
                    <div className="w-3 h-3 bg-secondary rounded-full flex-shrink-0"></div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">Complaint Submitted</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(complaint.createdAt), 'MMM dd, yyyy - hh:mm a')}
                      </p>
                    </div>
                  </div>

                  {updates.map((update, index) => (
                    <div key={update.id} className="flex items-center gap-4" data-testid={`timeline-update-${index}`}>
                      <div className={`w-3 h-3 rounded-full flex-shrink-0 ${
                        update.newStatus === 'resolved' ? 'bg-secondary' : 
                        update.newStatus === 'in-progress' ? 'bg-accent' : 'bg-primary'
                      }`}></div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground capitalize">
                          {update.newStatus.replace('-', ' ')}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(update.createdAt), 'MMM dd, yyyy - hh:mm a')}
                        </p>
                        {update.notes && (
                          <p className="text-sm text-muted-foreground mt-1">{update.notes}</p>
                        )}
                      </div>
                    </div>
                  ))}

                  {complaint.status !== 'resolved' && complaint.status !== 'rejected' && (
                    <div className="flex items-center gap-4" data-testid="timeline-pending">
                      <div className="w-3 h-3 bg-border rounded-full flex-shrink-0"></div>
                      <div className="flex-1">
                        <p className="font-medium text-muted-foreground">
                          {complaint.status === 'pending' ? 'Under Review' : 'Resolution'}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {complaint.status === 'pending' ? 'Waiting for assignment' : 'In progress'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <Separator className="my-6" />

              {/* Location & Contact */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Location
                  </h4>
                  <p className="text-muted-foreground text-sm mb-3">{complaint.address}</p>
                  <div className="bg-muted rounded-lg h-32 flex items-center justify-center">
                    <span className="text-muted-foreground text-sm">Map integration placeholder</span>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Contact & Evidence
                  </h4>
                  <div className="space-y-2 mb-4">
                    <p className="text-sm">
                      <span className="font-medium">Name:</span> {complaint.complainantName}
                    </p>
                    <p className="text-sm">
                      <span className="font-medium">Phone:</span> {complaint.complainantPhone}
                    </p>
                  </div>
                  
                  {complaint.images && complaint.images.length > 0 && (
                    <div>
                      <h5 className="font-medium text-foreground mb-2">Evidence Photos</h5>
                      <div className="grid grid-cols-2 gap-2">
                        {complaint.images.slice(0, 2).map((image, index) => (
                          <img
                            key={index}
                            src={`/api/uploads/${image}`}
                            alt={`Evidence ${index + 1}`}
                            className="rounded-lg h-20 w-full object-cover border border-border"
                            data-testid={`evidence-image-${index}`}
                          />
                        ))}
                        {complaint.images.length > 2 && (
                          <div className="bg-muted rounded-lg h-20 flex items-center justify-center border border-border">
                            <span className="text-xs text-muted-foreground">
                              +{complaint.images.length - 2} more
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
