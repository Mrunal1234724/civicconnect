import { Card, CardContent } from "@/components/ui/card";
import { 
  Eye, 
  Zap, 
  Heart, 
  Shield, 
  Smartphone, 
  Users, 
  TrendingUp, 
  Handshake,
  CheckCircle
} from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8 bg-background">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-6" data-testid="about-title">
            About CivicConnect
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Empowering citizens to build better communities through efficient civic issue reporting and resolution
          </p>
        </div>

        {/* Mission Section */}
        <Card className="mb-8 shadow-xl">
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold text-card-foreground mb-4" data-testid="mission-title">
              Our Mission
            </h2>
            <p className="text-muted-foreground mb-6">
              CivicConnect bridges the gap between citizens and local authorities by providing a streamlined platform 
              for reporting and tracking civic issues. We believe every community deserves responsive governance and 
              transparent problem resolution.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
              <div>
                <h3 className="text-lg font-semibold text-card-foreground mb-3">Key Features</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-center" data-testid="feature-ai-validation">
                    <CheckCircle className="w-4 h-4 text-secondary mr-2" />
                    AI-powered image validation
                  </li>
                  <li className="flex items-center" data-testid="feature-location-detection">
                    <CheckCircle className="w-4 h-4 text-secondary mr-2" />
                    Automatic location detection
                  </li>
                  <li className="flex items-center" data-testid="feature-priority-routing">
                    <CheckCircle className="w-4 h-4 text-secondary mr-2" />
                    Priority-based complaint routing
                  </li>
                  <li className="flex items-center" data-testid="feature-real-time-tracking">
                    <CheckCircle className="w-4 h-4 text-secondary mr-2" />
                    Real-time status tracking
                  </li>
                  <li className="flex items-center" data-testid="feature-sms-notifications">
                    <CheckCircle className="w-4 h-4 text-secondary mr-2" />
                    SMS notifications
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-card-foreground mb-3">Why Choose Us</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-center" data-testid="benefit-secure">
                    <Shield className="w-4 h-4 text-primary mr-2" />
                    Secure and reliable platform
                  </li>
                  <li className="flex items-center" data-testid="benefit-mobile-friendly">
                    <Smartphone className="w-4 h-4 text-primary mr-2" />
                    Mobile-friendly interface
                  </li>
                  <li className="flex items-center" data-testid="benefit-community-driven">
                    <Users className="w-4 h-4 text-primary mr-2" />
                    Community-driven approach
                  </li>
                  <li className="flex items-center" data-testid="benefit-data-driven">
                    <TrendingUp className="w-4 h-4 text-primary mr-2" />
                    Data-driven insights
                  </li>
                  <li className="flex items-center" data-testid="benefit-government-partnerships">
                    <Handshake className="w-4 h-4 text-primary mr-2" />
                    Government partnerships
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How We Make a Difference */}
        <Card className="shadow-xl">
          <CardContent className="p-8">
            <h2 className="text-2xl font-semibold text-card-foreground mb-6" data-testid="difference-title">
              How We Make a Difference
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center" data-testid="difference-transparency">
                <div className="bg-primary text-primary-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl">
                  <Eye className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold text-card-foreground mb-2">Transparency</h3>
                <p className="text-muted-foreground text-sm">
                  Every complaint is tracked publicly, ensuring accountability and progress visibility
                </p>
              </div>
              
              <div className="text-center" data-testid="difference-efficiency">
                <div className="bg-secondary text-secondary-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl">
                  <Zap className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold text-card-foreground mb-2">Efficiency</h3>
                <p className="text-muted-foreground text-sm">
                  AI-powered prioritization ensures urgent issues get immediate attention
                </p>
              </div>
              
              <div className="text-center" data-testid="difference-community">
                <div className="bg-accent text-accent-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl">
                  <Heart className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold text-card-foreground mb-2">Community</h3>
                <p className="text-muted-foreground text-sm">
                  Building stronger communities through collaborative civic engagement
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Technology Section */}
        <div className="mt-12">
          <Card className="shadow-xl">
            <CardContent className="p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-6" data-testid="technology-title">
                Advanced Technology
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-lg font-semibold text-card-foreground mb-3">AI-Powered Validation</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    Our advanced AI system automatically validates uploaded images to ensure they're relevant 
                    to the reported civic issues, reducing false reports and improving response efficiency.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-card-foreground mb-3">Smart Prioritization</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    Intelligent severity assessment combines user input with AI analysis to automatically 
                    prioritize complaints, ensuring critical safety issues receive immediate attention.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-card-foreground mb-3">Real-time Updates</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    Stay informed with instant SMS notifications and real-time tracking of your complaint 
                    status from submission to resolution.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-card-foreground mb-3">Location Accuracy</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    Precise GPS location detection and mapping integration ensure authorities can quickly 
                    locate and address reported issues.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Impact Stats */}
        <div className="mt-12">
          <Card className="shadow-xl">
            <CardContent className="p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-6 text-center" data-testid="impact-title">
                Our Impact
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
                <div data-testid="impact-complaints-resolved">
                  <div className="text-3xl font-bold text-primary mb-2">2,347</div>
                  <div className="text-muted-foreground text-sm">Complaints Resolved</div>
                </div>
                <div data-testid="impact-resolution-rate">
                  <div className="text-3xl font-bold text-secondary mb-2">94%</div>
                  <div className="text-muted-foreground text-sm">Resolution Rate</div>
                </div>
                <div data-testid="impact-average-days">
                  <div className="text-3xl font-bold text-accent mb-2">18</div>
                  <div className="text-muted-foreground text-sm">Average Days to Resolution</div>
                </div>
                <div data-testid="impact-active-users">
                  <div className="text-3xl font-bold text-primary mb-2">1,500+</div>
                  <div className="text-muted-foreground text-sm">Active Community Members</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
