import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { 
  AlertTriangle, 
  Search, 
  Construction, 
  Droplets, 
  Dog, 
  Trash2,
  Eye,
  Zap,
  Heart
} from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div 
        className="relative bg-gradient-to-br from-primary to-primary/80 text-primary-foreground py-24"
        style={{
          backgroundImage: "linear-gradient(rgba(30, 64, 175, 0.8), rgba(30, 64, 175, 0.9)), url('https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          backgroundSize: "cover",
          backgroundPosition: "center"
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6" data-testid="hero-title">
            Report Civic Issues in Your Community
          </h1>
          <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto" data-testid="hero-description">
            Help make your city better by reporting potholes, water logging, stray animals, and garbage overflow. 
            Your voice matters in building a cleaner, safer community.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/complaint">
              <Button 
                className="bg-accent text-accent-foreground px-8 py-4 text-lg font-semibold hover:bg-accent/90 transition-all transform hover:scale-105"
                data-testid="file-complaint-hero-button"
              >
                <AlertTriangle className="mr-2 h-5 w-5" />
                File a Complaint
              </Button>
            </Link>
            <Link href="/track">
              <Button 
                variant="secondary"
                className="bg-card text-card-foreground px-8 py-4 text-lg font-semibold hover:bg-card/90 transition-all"
                data-testid="track-status-hero-button"
              >
                <Search className="mr-2 h-5 w-5" />
                Track Status
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Issue Types Section */}
      <div className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="issue-types-title">
              What Can You Report?
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Our platform handles various civic issues to keep your community safe and clean
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="hover:shadow-xl transition-shadow" data-testid="issue-type-potholes">
              <CardContent className="p-6">
                <div className="text-accent text-3xl mb-4">
                  <Construction className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-card-foreground">Potholes</h3>
                <p className="text-muted-foreground">
                  Report dangerous potholes and road damage that need immediate attention
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-xl transition-shadow" data-testid="issue-type-waterlogging">
              <CardContent className="p-6">
                <div className="text-accent text-3xl mb-4">
                  <Droplets className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-card-foreground">Water Logging</h3>
                <p className="text-muted-foreground">
                  Report areas with poor drainage and water accumulation issues
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-xl transition-shadow" data-testid="issue-type-stray-animals">
              <CardContent className="p-6">
                <div className="text-accent text-3xl mb-4">
                  <Dog className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-card-foreground">Stray Animals</h3>
                <p className="text-muted-foreground">
                  Help manage stray dog populations and ensure community safety
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-xl transition-shadow" data-testid="issue-type-garbage">
              <CardContent className="p-6">
                <div className="text-accent text-3xl mb-4">
                  <Trash2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-card-foreground">Garbage Overflow</h3>
                <p className="text-muted-foreground">
                  Report overflowing bins and improper waste disposal areas
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="how-it-works-title">
              How It Works
            </h2>
            <p className="text-muted-foreground text-lg">
              Simple steps to make a difference in your community
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center" data-testid="step-1">
              <div className="bg-primary text-primary-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                1
              </div>
              <h3 className="text-xl font-semibold mb-3">Report Issue</h3>
              <p className="text-muted-foreground">
                Take a photo, describe the problem, and our AI will verify and prioritize it
              </p>
            </div>
            <div className="text-center" data-testid="step-2">
              <div className="bg-primary text-primary-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                2
              </div>
              <h3 className="text-xl font-semibold mb-3">Track Progress</h3>
              <p className="text-muted-foreground">
                Monitor your complaint status and receive updates via SMS
              </p>
            </div>
            <div className="text-center" data-testid="step-3">
              <div className="bg-primary text-primary-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                3
              </div>
              <h3 className="text-xl font-semibold mb-3">Get Resolution</h3>
              <p className="text-muted-foreground">
                Local authorities address the issue and update you on completion
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div data-testid="stat-resolved">
              <div className="text-3xl font-bold text-primary mb-2">2,347</div>
              <div className="text-muted-foreground">Complaints Resolved</div>
            </div>
            <div data-testid="stat-resolution-rate">
              <div className="text-3xl font-bold text-secondary mb-2">94%</div>
              <div className="text-muted-foreground">Resolution Rate</div>
            </div>
            <div data-testid="stat-avg-days">
              <div className="text-3xl font-bold text-accent mb-2">18</div>
              <div className="text-muted-foreground">Avg Days to Fix</div>
            </div>
            <div data-testid="stat-active-users">
              <div className="text-3xl font-bold text-primary mb-2">1,500+</div>
              <div className="text-muted-foreground">Active Users</div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Why Choose CivicConnect?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center" data-testid="feature-transparency">
              <div className="bg-primary text-primary-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl">
                <Eye className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Transparency</h3>
              <p className="text-muted-foreground text-sm">
                Every complaint is tracked publicly, ensuring accountability and progress visibility
              </p>
            </div>
            <div className="text-center" data-testid="feature-efficiency">
              <div className="bg-secondary text-secondary-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl">
                <Zap className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Efficiency</h3>
              <p className="text-muted-foreground text-sm">
                AI-powered prioritization ensures urgent issues get immediate attention
              </p>
            </div>
            <div className="text-center" data-testid="feature-community">
              <div className="bg-accent text-accent-foreground rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Community</h3>
              <p className="text-muted-foreground text-sm">
                Building stronger communities through collaborative civic engagement
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      {!isAuthenticated && (
        <div className="py-16 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-primary-foreground mb-4">
              Ready to Make a Difference?
            </h2>
            <p className="text-primary-foreground/90 text-lg mb-8 max-w-2xl mx-auto">
              Join thousands of citizens who are actively improving their communities
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <Button 
                  size="lg" 
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                  data-testid="cta-signup-button"
                >
                  Get Started Today
                </Button>
              </Link>
              <Link href="/about">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
                  data-testid="cta-learn-more-button"
                >
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
