/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_FIREBASE_API_KEY: "AIzaSyAyar4pVF2hYb0pTaaTHIrkY9QYwLrAkn4";
  readonly VITE_FIREBASE_AUTH_DOMAIN: "civicconnect-pro.firebaseapp.com";
  readonly VITE_FIREBASE_PROJECT_ID: "civicconnect-pro";
  readonly VITE_FIREBASE_APP_ID: "1:979185208965:web:b7a725fe6cdcbecc8b23ec";
  readonly VITE_FIREBASE_MESSAGING_SENDER_ID: "979185208965";
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
