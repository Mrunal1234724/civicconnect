import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getAdminComplaints, updateComplaintStatus } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Eye, Edit, CheckCircle, Clock, AlertTriangle, Calendar, Phone, MapPin } from "lucide-react";
import { format } from "date-fns";

interface Complaint {
  id: string;
  trackingId: string;
  issueType: string;
  title: string;
  description: string;
  address: string;
  status: string;
  severityFinal: string;
  complainantName: string;
  complainantPhone: string;
  images: string[];
  createdAt: string;
  updatedAt: string;
}

interface ComplaintsTableProps {
  filters: {
    status: string;
    priority: string;
    issueType: string;
  };
}

export default function ComplaintsTable({ filters }: ComplaintsTableProps) {
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [statusUpdate, setStatusUpdate] = useState("");
  const [statusNotes, setStatusNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: complaintsData, isLoading } = useQuery({
    queryKey: ['/api/admin/complaints', filters],
    queryFn: () => getAdminComplaints(filters),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status, notes }: { id: string; status: string; notes?: string }) =>
      updateComplaintStatus(id, status, notes),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/complaints'] });
      toast({
        title: "Status Updated",
        description: "Complaint status has been updated successfully.",
      });
      setSelectedComplaint(null);
      setStatusUpdate("");
      setStatusNotes("");
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Failed to update status",
        variant: "destructive",
      });
    },
  });

  const getSeverityBadge = (severity: string) => {
    const variants = {
      high: "destructive",
      medium: "default",
      low: "secondary",
    } as const;

    const colors = {
      high: "bg-red-100 text-red-800 border-red-200",
      medium: "bg-yellow-100 text-yellow-800 border-yellow-200", 
      low: "bg-green-100 text-green-800 border-green-200",
    } as const;

    return (
      <Badge 
        className={colors[severity as keyof typeof colors] || colors.medium}
        data-testid={`severity-badge-${severity}`}
      >
        {severity?.toUpperCase()}
      </Badge>
    );
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
      "in-progress": "bg-blue-100 text-blue-800 border-blue-200",
      resolved: "bg-green-100 text-green-800 border-green-200",
      rejected: "bg-red-100 text-red-800 border-red-200",
    } as const;

    return (
      <Badge 
        className={colors[status as keyof typeof colors] || colors.pending}
        data-testid={`status-badge-${status}`}
      >
        {status?.replace('-', ' ').toUpperCase()}
      </Badge>
    );
  };

  const getIssueIcon = (issueType: string) => {
    const icons = {
      pothole: "🕳️",
      waterlogging: "💧",
      "stray-dogs": "🐕",
      "garbage-overflow": "🗑️",
    } as const;

    return icons[issueType as keyof typeof icons] || "📋";
  };

  const handleStatusChange = () => {
    if (!selectedComplaint || !statusUpdate) return;

    updateStatusMutation.mutate({
      id: selectedComplaint.id,
      status: statusUpdate,
      notes: statusNotes || undefined,
    });
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading complaints...</p>
        </CardContent>
      </Card>
    );
  }

  const complaints = complaintsData?.complaints || [];

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Complaints ({complaints.length})</span>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Last updated: {format(new Date(), 'HH:mm')}</span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {complaints.map((complaint: Complaint) => (
                  <TableRow key={complaint.id} data-testid={`complaint-row-${complaint.trackingId}`}>
                    <TableCell className="font-medium">
                      {complaint.trackingId}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getIssueIcon(complaint.issueType)}</span>
                        <span className="capitalize">{complaint.issueType.replace('-', ' ')}</span>
                      </div>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {complaint.address}
                    </TableCell>
                    <TableCell>
                      {getSeverityBadge(complaint.severityFinal)}
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(complaint.status)}
                    </TableCell>
                    <TableCell>
                      {format(new Date(complaint.createdAt), 'MMM dd, yyyy')}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => setSelectedComplaint(complaint)}
                              data-testid={`view-complaint-${complaint.trackingId}`}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>
                                Complaint Details - {complaint.trackingId}
                              </DialogTitle>
                            </DialogHeader>
                            {selectedComplaint && (
                              <ComplaintDetailsModal 
                                complaint={selectedComplaint}
                                onStatusUpdate={(status, notes) => {
                                  setStatusUpdate(status);
                                  setStatusNotes(notes);
                                  handleStatusChange();
                                }}
                              />
                            )}
                          </DialogContent>
                        </Dialog>

                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedComplaint(complaint);
                                setStatusUpdate(complaint.status);
                                setStatusNotes("");
                              }}
                              data-testid={`update-status-${complaint.trackingId}`}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Update Status - {complaint.trackingId}</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label htmlFor="status">New Status</Label>
                                <Select value={statusUpdate} onValueChange={setStatusUpdate}>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select status" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">Pending</SelectItem>
                                    <SelectItem value="in-progress">In Progress</SelectItem>
                                    <SelectItem value="resolved">Resolved</SelectItem>
                                    <SelectItem value="rejected">Rejected</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label htmlFor="notes">Update Notes (Optional)</Label>
                                <Textarea
                                  id="notes"
                                  value={statusNotes}
                                  onChange={(e) => setStatusNotes(e.target.value)}
                                  placeholder="Add any notes about this status update..."
                                  data-testid="status-notes-textarea"
                                />
                              </div>
                              <Button 
                                onClick={handleStatusChange}
                                disabled={!statusUpdate || updateStatusMutation.isPending}
                                className="w-full"
                                data-testid="confirm-status-update"
                              >
                                {updateStatusMutation.isPending ? "Updating..." : "Update Status"}
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {complaint.status !== 'resolved' && (
                          <Button 
                            size="sm"
                            variant="secondary"
                            onClick={() => {
                              updateStatusMutation.mutate({
                                id: complaint.id,
                                status: 'resolved',
                                notes: 'Marked as resolved'
                              });
                            }}
                            data-testid={`resolve-complaint-${complaint.trackingId}`}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {complaints.length === 0 && (
            <div className="text-center py-8">
              <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No complaints found matching the current filters.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}

function ComplaintDetailsModal({ complaint, onStatusUpdate }: { 
  complaint: Complaint; 
  onStatusUpdate: (status: string, notes: string) => void;
}) {
  const [newStatus, setNewStatus] = useState(complaint.status);
  const [notes, setNotes] = useState("");

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <h4 className="font-semibold text-sm text-muted-foreground">Issue Type</h4>
          <p className="font-medium capitalize">{complaint.issueType.replace('-', ' ')}</p>
        </div>
        <div>
          <h4 className="font-semibold text-sm text-muted-foreground">Priority</h4>
          <div className="mt-1">{complaint.severityFinal}</div>
        </div>
        <div>
          <h4 className="font-semibold text-sm text-muted-foreground">Current Status</h4>
          <div className="mt-1">{complaint.status.replace('-', ' ').toUpperCase()}</div>
        </div>
      </div>

      {/* Description */}
      <div>
        <h4 className="font-semibold mb-2">Description</h4>
        <p className="text-muted-foreground">{complaint.description}</p>
      </div>

      {/* Location & Contact */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Location
          </h4>
          <p className="text-sm text-muted-foreground">{complaint.address}</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <Phone className="w-4 h-4" />
            Contact
          </h4>
          <p className="text-sm">{complaint.complainantName}</p>
          <p className="text-sm text-muted-foreground">{complaint.complainantPhone}</p>
        </div>
      </div>

      {/* Images */}
      {complaint.images && complaint.images.length > 0 && (
        <div>
          <h4 className="font-semibold mb-2">Evidence Photos</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {complaint.images.map((image, index) => (
              <img
                key={index}
                src={`/api/uploads/${image}`}
                alt={`Evidence ${index + 1}`}
                className="w-full h-20 object-cover rounded border"
                data-testid={`evidence-image-${index}`}
              />
            ))}
          </div>
        </div>
      )}

      {/* Status Update Section */}
      <div className="border-t pt-4">
        <h4 className="font-semibold mb-4">Update Status</h4>
        <div className="space-y-4">
          <div>
            <Label>New Status</Label>
            <Select value={newStatus} onValueChange={setNewStatus}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Notes</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add update notes..."
            />
          </div>
          <Button 
            onClick={() => onStatusUpdate(newStatus, notes)}
            disabled={newStatus === complaint.status}
            className="w-full"
          >
            Update Status
          </Button>
        </div>
      </div>
    </div>
  );
}
