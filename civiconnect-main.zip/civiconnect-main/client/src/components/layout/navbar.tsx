import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User, LogOut, Settings, LayoutDashboard } from "lucide-react";

export default function Navbar() {
  const [location] = useLocation();
  const { user, isAuthenticated, isAdmin, logout } = useAuth();

  const handleLogout = () => {
    logout();
  };

  const navLinkClass = (path: string) =>
    `px-3 py-2 rounded-md text-sm font-medium transition-colors ${
      location === path
        ? "text-primary font-semibold"
        : "text-muted-foreground hover:text-foreground"
    }`;

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo + Links */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <h1 className="text-xl font-bold text-primary cursor-pointer">
                  <i className="fas fa-city mr-2"></i>CivicConnect
                </h1>
              </Link>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex space-x-8">
                <Link href="/">
                  <a className={navLinkClass("/")} data-testid="nav-home">
                    Home
                  </a>
                </Link>
                <Link href="/complaint">
                  <a className={navLinkClass("/complaint")} data-testid="nav-complaint">
                    File Complaint
                  </a>
                </Link>
                <Link href="/track">
                  <a className={navLinkClass("/track")} data-testid="nav-track">
                    Track Complaint
                  </a>
                </Link>
                <Link href="/about">
                  <a className={navLinkClass("/about")} data-testid="nav-about">
                    About
                  </a>
                </Link>
                <Link href="/contact">
                  <a className={navLinkClass("/contact")} data-testid="nav-contact">
                    Contact
                  </a>
                </Link>
              </div>
            </div>
          </div>

          {/* Right Side (Auth) */}
          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center space-x-2"
                    data-testid="user-menu"
                  >
                    <User className="h-4 w-4" />
                    <span>{user?.name}</span>
                  </Button>
                </DropdownMenuTrigger>

                <DropdownMenuContent align="end">
                  {isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin/dashboard">
                        <LayoutDashboard className="mr-2 h-4 w-4" />
                        <span>Dashboard</span>
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={handleLogout}
                    data-testid="logout-button"
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="ghost" data-testid="login-button">
                    Login
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button
                    className="bg-primary text-primary-foreground"
                    data-testid="signup-button"
                  >
                    Sign Up
                  </Button>
                </Link>
                <Link href="/admin/login">
                  <Button
                    className="bg-secondary text-secondary-foreground"
                    data-testid="admin-login-button"
                  >
                    Admin
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
