// complaint-form.tsx
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import LocationPicker from "./location-picker";
import ImageUpload from "./image-upload";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Send } from "lucide-react";

const complaintSchema = z.object({
  issueType: z.string().min(1, "Please select an issue type"),
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  address: z.string().min(10, "Please provide a detailed address"),
  severityUser: z.enum(["low", "medium", "high"]),
  complainantName: z.string().min(2, "Name is required"),
  complainantPhone: z.string().min(10, "Valid phone number is required"),
});

type ComplaintFormData = z.infer<typeof complaintSchema>;

export default function ComplaintForm() {
  const [images, setImages] = useState<File[]>([]);
  const [latitude, setLatitude] = useState<string>("");
  const [longitude, setLongitude] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();

  const form = useForm<ComplaintFormData>({
    resolver: zodResolver(complaintSchema),
    defaultValues: {
      issueType: "",
      title: "",
      description: "",
      address: "",
      severityUser: "medium",
      complainantName: user?.name || "",
      complainantPhone: "",
    },
  });

  const onSubmit = async (data: ComplaintFormData) => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to submit a complaint.",
        variant: "destructive",
      });
      return;
    }

    if (images.length === 0) {
      toast({
        title: "Images Required",
        description: "Please upload at least one image of the issue.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    try {
      const formData = new FormData();
      formData.append("userId", user?.id || "");
      formData.append("description", data.description);
      formData.append("title", data.title);
      formData.append("issueType", data.issueType);
      formData.append("address", data.address);
      formData.append("severityUser", data.severityUser);
      formData.append("complainantName", data.complainantName);
      formData.append("complainantPhone", data.complainantPhone);
      formData.append("latitude", latitude);
      formData.append("longitude", longitude);

      // ✅ FIX: always append with "images"
      images.forEach((file) => {
        formData.append("images", file);
      });

      const res = await fetch("/api/complaints", {
        method: "POST",
        body: formData,
      });

      const result = await res.json();

      if (res.ok) {
        toast({
          title: "Complaint Submitted",
          description: `Tracking ID: ${result.trackingId || result.id}`,
        });

        form.reset();
        setImages([]);
        setLatitude("");
        setLongitude("");
      } else {
        toast({
          title: "Submission Failed",
          description: result.message || "Failed to submit complaint",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Submit complaint error:", error);
      toast({
        title: "Submission Failed",
        description:
          error instanceof Error
            ? error.message
            : "Failed to submit complaint. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const issueTypeOptions = [
    { value: "pothole", label: "Pothole" },
    { value: "waterlogging", label: "Water Logging" },
    { value: "stray-dogs", label: "Stray Dogs" },
    { value: "garbage-overflow", label: "Garbage Overflow" },
  ];

  return (
    <Card className="max-w-2xl mx-auto">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-card-foreground">
            File a Complaint
          </h2>
          <p className="text-muted-foreground mt-2">
            Help us improve your community by reporting civic issues
          </p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Issue Type */}
            <FormField
              control={form.control}
              name="issueType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Issue Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select issue type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {issueTypeOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe the issue" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Severity */}
            <FormField
              control={form.control}
              name="severityUser"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Severity</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      value={field.value}
                      className="flex gap-4"
                    >
                      <FormItem>
                        <FormControl>
                          <RadioGroupItem value="low" />
                        </FormControl>
                        <FormLabel>Low</FormLabel>
                      </FormItem>
                      <FormItem>
                        <FormControl>
                          <RadioGroupItem value="medium" />
                        </FormControl>
                        <FormLabel>Medium</FormLabel>
                      </FormItem>
                      <FormItem>
                        <FormControl>
                          <RadioGroupItem value="high" />
                        </FormControl>
                        <FormLabel>High</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Complainant Name */}
            <FormField
              control={form.control}
              name="complainantName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter your name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Complainant Phone */}
            <FormField
              control={form.control}
              name="complainantPhone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter phone number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Location Picker */}
            <div>
              <LocationPicker
                address={form.watch("address")}
                onAddressChange={(addr) => form.setValue("address", addr)}
                latitude={latitude}
                longitude={longitude}
                onCoordinatesChange={(lat, lng) => {
                  setLatitude(lat);
                  setLongitude(lng);
                }}
              />
            </div>

            {/* Image Upload */}
            <div>
              <ImageUpload
                images={images}
                onImagesChange={(newImages: File[]) => setImages(newImages)}
              />
            </div>

            {/* Submit */}
            <div className="pt-6">
              <Button
                type="submit"
                className="w-full text-lg py-6"
                disabled={submitting}
                data-testid="submit-complaint-button"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Submitting Complaint...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Submit Complaint
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
