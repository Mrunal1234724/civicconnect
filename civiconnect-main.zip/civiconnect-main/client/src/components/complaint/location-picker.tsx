import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LocationPickerProps {
  address: string;
  onAddressChange: (address: string) => void;
  onCoordinatesChange: (lat: string, lng: string) => void;
}

export default function LocationPicker({
  address,
  onAddressChange,
  onCoordinatesChange,
}: LocationPickerProps) {
  const { toast } = useToast();
  const [locating, setLocating] = useState(false);

  const handleUseCurrentLocation = () => {
    if (!("geolocation" in navigator)) {
      toast({
        title: "Geolocation unavailable",
        description: "Your browser does not support geolocation.",
        variant: "destructive",
      });
      return;
    }

    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;

          const resp = await fetch(
            `https://us1.locationiq.com/v1/reverse?key=${
              import.meta.env.VITE_LOCATIONIQ_API_KEY
            }&lat=${lat}&lon=${lng}&format=json`
          );

          if (!resp.ok) throw new Error("Failed to fetch address");
          const data = await resp.json();

          onAddressChange(data.display_name || "");
          onCoordinatesChange(lat.toString(), lng.toString());

          toast({
            title: "Location detected",
            description: `Accuracy: ${Math.round(pos.coords.accuracy)}m`,
          });
        } catch (err) {
          toast({
            title: "Location Error",
            description: "Could not fetch address from LocationIQ",
            variant: "destructive",
          });
        } finally {
          setLocating(false);
        }
      },
      (err) => {
        console.error(err);
        setLocating(false);
        toast({
          title: "Location Error",
          description: err.message || "Failed to get location.",
          variant: "destructive",
        });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <Label htmlFor="address" className="text-base font-semibold">
          Location Information
        </Label>
        <Button
          type="button"
          variant="secondary"
          onClick={handleUseCurrentLocation}
          disabled={locating}
        >
          {locating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" /> Detecting...
            </>
          ) : (
            <>
              <MapPin className="w-4 h-4" /> Use Current Location
            </>
          )}
        </Button>
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">Full Address</Label>
        <Input
          id="address"
          value={address}
          onChange={(e) => onAddressChange(e.target.value)}
          placeholder="Enter the complete address"
        />
      </div>
    </div>
  );
}
