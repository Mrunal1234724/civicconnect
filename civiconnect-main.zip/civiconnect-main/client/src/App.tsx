import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import Navbar from "@/components/layout/navbar";

import Home from "@/pages/home";
import Login from "@/pages/login";
import Signup from "@/pages/signup";
import AdminLogin from "@/pages/admin-login";
import AdminSignup from "@/pages/admin-signup";
import AdminDashboard from "@/pages/admin-dashboard";
import Complaint from "@/pages/complaint";
import Track from "@/pages/track";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import Profile from "@/pages/profile"; // ✅ added
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/signup" component={Signup} />
        <Route path="/admin/login" component={AdminLogin} />
        <Route path="/admin/signup" component={AdminSignup} />

        {/* ✅ Protect Admin Dashboard */}
        <Route path="/admin/dashboard">
          {() =>
            localStorage.getItem("isAdmin") === "true" ? (
              <AdminDashboard />
            ) : (
              <div className="p-8 text-center">
                <h1 className="text-2xl font-bold text-red-600">
                  Access Denied
                </h1>
                <p className="text-muted-foreground mt-2">
                  Please log in as admin to access this page.
                </p>
              </div>
            )
          }
        </Route>

        <Route path="/complaint" component={Complaint} />
        <Route path="/track" component={Track} />
        <Route path="/about" component={About} />
        <Route path="/contact" component={Contact} />

        {/* ✅ Added new profile route */}
        <Route path="/profile" component={Profile} />

        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <Toaster />
          <Router />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
