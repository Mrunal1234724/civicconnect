// src/lib/api.ts
import { auth } from "./firebaseAuth";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000"; // backend URL

// 🧩 Type for complaint data
export interface ComplaintData {
  issueType: string;
  title: string;
  description: string;
  address: string;
  latitude?: string;
  longitude?: string;
  severityUser: string;
  complainantName: string;
  complainantPhone: string;
}

// 🔹 Safely parse JSON responses
async function safeJson(response: Response) {
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    console.error("Expected JSON, but got:", text);
    throw new Error("Server did not return valid JSON");
  }
}

// 🔹 Get Firebase Auth header dynamically
async function getFirebaseAuthHeaders(): Promise<Record<string, string>> {
  const currentUser = auth.currentUser;
  if (!currentUser) return {};
  const token = await currentUser.getIdToken();
  return { Authorization: `Bearer ${token}` };
}

// 🔹 Centralized fetch helper with Firebase token
async function apiFetch(endpoint: string, options: RequestInit = {}) {
  const authHeaders = await getFirebaseAuthHeaders();

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      ...authHeaders,
      ...(options.headers || {}),
    },
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error("❌ API request failed:", endpoint, res.status, errorText);
    throw new Error(errorText || "API request failed");
  }

  return safeJson(res);
}

// 🧾 Complaint APIs

export async function submitComplaint(
  data: ComplaintData,
  images: File[]
): Promise<any> {
  const formData = new FormData();
  Object.entries(data).forEach(([key, value]) => {
    if (value != null) formData.append(key, value);
  });
  images.forEach((image) => formData.append("images", image));

  return apiFetch("/api/complaints", { method: "POST", body: formData });
}

export async function trackComplaint(trackingId: string): Promise<any> {
  return apiFetch(`/api/complaints/track/${trackingId}`);
}

export async function getUserComplaints(): Promise<any> {
  return apiFetch("/api/complaints/my");
}

export async function getAdminComplaints(
  filters: Record<string, string> = {}
): Promise<any> {
  const params = new URLSearchParams(filters).toString();
  return apiFetch(`/api/admin/complaints?${params}`);
}

export async function updateComplaintStatus(
  id: string,
  status: string,
  notes?: string
): Promise<any> {
  return apiFetch(`/api/admin/complaints/${id}/status`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status, notes }),
  });
}

export async function assignComplaint(
  id: string,
  adminId: string
): Promise<any> {
  return apiFetch(`/api/admin/complaints/${id}/assign`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ adminId }),
  });
}

export async function submitContactForm(data: any): Promise<any> {
  return apiFetch("/api/contact", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
}
