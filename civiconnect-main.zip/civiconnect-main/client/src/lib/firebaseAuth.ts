import { initializeApp } from "firebase/app";
import { getAuth, RecaptchaVerifier, Auth } from "firebase/auth";

// ✅ Replace with your Firebase config values from .env
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth: Auth = getAuth(app);
auth.languageCode = "en"; // optional (sets SMS language)

// 🔹 Add TypeScript type for global window
declare global {
  interface Window {
    recaptchaVerifier?: RecaptchaVerifier;
  }
}

/**
 * 🔹 Create and return a reCAPTCHA verifier for phone auth
 */
export function createRecaptchaVerifier(): RecaptchaVerifier {
  if (!window.recaptchaVerifier) {
    window.recaptchaVerifier = new RecaptchaVerifier(
      "recaptcha-container", // ✅ HTML element ID
      {
        size: "invisible", // hides widget
        callback: () => {
          console.log("✅ reCAPTCHA verified successfully");
        },
        "expired-callback": () => {
          console.warn("⚠️ reCAPTCHA expired. Please try again.");
        },
      },
      auth // ✅ must be passed as the third argument
    );
  }

  return window.recaptchaVerifier;
}
