// src/lib/auth.ts
import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult,
  getIdToken,
} from "firebase/auth";

// 🔹 Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// ✅ Initialize Firebase app only once
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

// ✅ Initialize reCAPTCHA verifier (corrected for Firebase v10+)
export const initRecaptcha = () => {
  if (!window.recaptchaVerifier) {
    // ✅ Correct argument order: (auth, containerId, options)
    window.recaptchaVerifier = new RecaptchaVerifier(
      auth,
      "recaptcha-container",
      {
        size: "normal", // change to "invisible" if you want it hidden
        callback: (response: any) => {
          console.log("✅ reCAPTCHA verified:", response);
        },
        "expired-callback": () => {
          console.warn("⚠️ reCAPTCHA expired, resetting...");
          window.recaptchaVerifier?.clear();
          delete window.recaptchaVerifier;
        },
      }
    );

    // ✅ Render the reCAPTCHA widget
    window.recaptchaVerifier.render().then((widgetId) => {
      console.log("🧩 reCAPTCHA widget rendered:", widgetId);
    });
  }
};

// ✅ Send OTP
export const sendOTP = async (phoneNumber: string) => {
  if (!window.recaptchaVerifier) initRecaptcha();

  const appVerifier = window.recaptchaVerifier;
  if (!appVerifier) throw new Error("reCAPTCHA not initialized");

  try {
    const confirmationResult = await signInWithPhoneNumber(
      auth,
      phoneNumber,
      appVerifier
    );
    window.confirmationResult = confirmationResult;
    console.log("📱 OTP sent successfully!");
    return confirmationResult;
  } catch (error: any) {
    console.error("❌ Failed to send OTP:", error);
    throw error;
  }
};

// ✅ Verify OTP
export const verifyOTP = async (otp: string) => {
  if (!window.confirmationResult) throw new Error("OTP not requested yet");
  const result = await window.confirmationResult.confirm(otp);
  console.log("✅ OTP verified successfully!");
  return result.user;
};

// ✅ Helper: Return Authorization header for API requests
export const getAuthHeaders = async (): Promise<Record<string, string>> => {
  const user = auth.currentUser;
  if (!user) return {};
  const token = await getIdToken(user);
  return { Authorization: `Bearer ${token}` };
};

// ✅ Declare global window types
declare global {
  interface Window {
    recaptchaVerifier?: RecaptchaVerifier;
    confirmationResult?: ConfirmationResult;
  }
}
