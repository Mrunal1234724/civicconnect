export interface ComplaintData {
  _id?: string;           
  issueType: string;
  title: string;
  description: string;
  address: string;
  latitude?: string;
  longitude?: string;
  severityUser: string;
  complainantName: string;
  complainantPhone: string;
  status?: string;        
  trackingId?: string;    
  createdAt?: string;
}

const API_BASE = "http://localhost:5000";

// Read token from localStorage
function getAuthHeaders(): Record<string, string> {
  const token = localStorage.getItem("authToken");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// 🔹 Submit complaint
export async function submitComplaint(
  data: ComplaintData,
  images: File[]
): Promise<ComplaintData> {
  const formData = new FormData();

  Object.entries(data).forEach(([k, v]) => {
    if (v !== undefined && v !== null) formData.append(k, String(v));
  });
  images.forEach((file) => formData.append("images", file));

  const res = await fetch(`${API_BASE}/api/complaints`, {
    method: "POST",
    body: formData,
    headers: {
      ...getAuthHeaders(),
      Accept: "application/json",
    } as HeadersInit,
  });

  const parsed: any = await res.json();
  if (!res.ok) throw new Error(parsed?.error || parsed?.message || "Failed to submit");

  return {
    ...data,
    _id: parsed._id,
    trackingId: parsed.trackingId,
    status: parsed.status || "pending",
    createdAt: parsed.createdAt,
  };
}

// 🔹 Get all complaints for logged-in user
export async function getUserComplaints(): Promise<ComplaintData[]> {
  const res = await fetch(`${API_BASE}/api/complaints/my`, {
    headers: {
      ...getAuthHeaders(),
      Accept: "application/json",
    },
  });

  const parsed: any = await res.json();

  if (!res.ok) throw new Error(parsed?.error || parsed?.message || "Failed to fetch complaints");

  // Handle backend returning { data: [...] } or just [...]
  if (Array.isArray(parsed)) return parsed;
  if (parsed && Array.isArray(parsed.data)) return parsed.data;

  return [];
}
