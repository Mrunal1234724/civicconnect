import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const issueTypeEnum = pgEnum('issue_type', ['pothole', 'waterlogging', 'stray-dogs', 'garbage-overflow']);
export const severityEnum = pgEnum('severity', ['low', 'medium', 'high']);
export const statusEnum = pgEnum('status', ['pending', 'in-progress', 'resolved', 'rejected']);
export const userRoleEnum = pgEnum('user_role', ['user', 'admin']);
export const departmentEnum = pgEnum('department', ['roads', 'sanitation', 'water', 'animal-control']);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").default('user').notNull(),
  isVerified: boolean("is_verified").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Admins table (separate from users for additional admin-specific fields)
export const admins = pgTable("admins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  employeeId: text("employee_id").notNull().unique(),
  department: departmentEnum("department").notNull(),
  isApproved: boolean("is_approved").default(false).notNull(),
  approvedAt: timestamp("approved_at"),
  approvedBy: varchar("approved_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// OTP verification table
export const otpVerifications = pgTable("otp_verifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phone: text("phone").notNull(),
  otp: text("otp").notNull(),
  isUsed: boolean("is_used").default(false).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Complaints table
export const complaints = pgTable("complaints", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  issueType: issueTypeEnum("issue_type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  address: text("address").notNull(),
  latitude: text("latitude"),
  longitude: text("longitude"),
  images: jsonb("images").$type<string[]>().default([]).notNull(),
  severityUser: severityEnum("severity_user").notNull(),
  severityAI: severityEnum("severity_ai"),
  severityFinal: severityEnum("severity_final"),
  status: statusEnum("status").default('pending').notNull(),
  assignedTo: varchar("assigned_to").references(() => admins.id),
  complainantName: text("complainant_name").notNull(),
  complainantPhone: text("complainant_phone").notNull(),
  isValidated: boolean("is_validated").default(false).notNull(),
  validationResult: jsonb("validation_result").$type<{
    isRelevant: boolean;
    confidence: number;
    reason: string;
  }>(),
  trackingId: text("tracking_id").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Complaint updates/history table
export const complaintUpdates = pgTable("complaint_updates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  complaintId: varchar("complaint_id").references(() => complaints.id).notNull(),
  updatedBy: varchar("updated_by").references(() => users.id).notNull(),
  previousStatus: statusEnum("previous_status"),
  newStatus: statusEnum("new_status").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  complaints: many(complaints),
  complaintUpdates: many(complaintUpdates),
  adminProfile: one(admins, {
    fields: [users.id],
    references: [admins.userId],
  }),
}));

export const adminsRelations = relations(admins, ({ one, many }) => ({
  user: one(users, {
    fields: [admins.userId],
    references: [users.id],
  }),
  assignedComplaints: many(complaints),
  approver: one(users, {
    fields: [admins.approvedBy],
    references: [users.id],
  }),
}));

export const complaintsRelations = relations(complaints, ({ one, many }) => ({
  user: one(users, {
    fields: [complaints.userId],
    references: [users.id],
  }),
  assignedAdmin: one(admins, {
    fields: [complaints.assignedTo],
    references: [admins.id],
  }),
  updates: many(complaintUpdates),
}));

export const complaintUpdatesRelations = relations(complaintUpdates, ({ one }) => ({
  complaint: one(complaints, {
    fields: [complaintUpdates.complaintId],
    references: [complaints.id],
  }),
  updatedByUser: one(users, {
    fields: [complaintUpdates.updatedBy],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  isVerified: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAdminSchema = createInsertSchema(admins).omit({
  id: true,
  isApproved: true,
  approvedAt: true,
  approvedBy: true,
  createdAt: true,
});

export const insertComplaintSchema = createInsertSchema(complaints).omit({
  id: true,
  userId: true,
  severityAI: true,
  severityFinal: true,
  status: true,
  assignedTo: true,
  isValidated: true,
  validationResult: true,
  trackingId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOtpSchema = createInsertSchema(otpVerifications).omit({
  id: true,
  isUsed: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type Complaint = typeof complaints.$inferSelect;
export type InsertComplaint = z.infer<typeof insertComplaintSchema>;
export type ComplaintUpdate = typeof complaintUpdates.$inferSelect;
export type OtpVerification = typeof otpVerifications.$inferSelect;
export type InsertOtp = z.infer<typeof insertOtpSchema>;

// Login schemas
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const otpVerifySchema = z.object({
  phone: z.string().min(10),
  otp: z.string().length(6),
});

export type LoginData = z.infer<typeof loginSchema>;
export type OtpVerifyData = z.infer<typeof otpVerifySchema>;
