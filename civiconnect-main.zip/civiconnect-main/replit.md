# CivicConnect

## Overview

CivicConnect is a full-stack web application that enables citizens to report civic issues (potholes, water logging, stray animals, garbage overflow) to local authorities. The platform features AI-powered image validation, real-time tracking, SMS notifications, and comprehensive admin management tools. Built with modern web technologies, it provides an intuitive interface for citizens and efficient workflow management for municipal administrators.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for build tooling
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming support
- **State Management**: TanStack React Query for server state and custom React Context for authentication
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation schemas

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with structured error handling and request logging middleware
- **Authentication**: JWT tokens with bcrypt password hashing
- **File Handling**: Multer for image uploads with Sharp for image processing
- **Middleware**: Custom authentication, role-based access control, and verification requirements

### Database & ORM
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with type-safe schema definitions
- **Schema**: Relational design with users, admins, complaints, updates, and OTP verification tables
- **Migrations**: Drizzle Kit for schema management and migrations

### External Dependencies

#### Third-party Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **OpenAI API**: GPT-5 model for AI-powered image validation and issue severity assessment
- **Twilio**: SMS service for OTP verification and complaint status notifications
- **Geolocation APIs**: Browser-based location services for automatic address detection

#### Key Libraries
- **Sharp**: High-performance image processing for file optimization
- **Multer**: Multipart form data handling for file uploads
- **bcrypt**: Secure password hashing with salt rounds
- **jsonwebtoken**: JWT token generation and verification
- **date-fns**: Date formatting and manipulation utilities

#### Development Tools
- **Vite**: Fast build tool with HMR and development server
- **Replit Plugins**: Development banner, cartographer, and runtime error overlay
- **TypeScript**: Static type checking across frontend and backend
- **PostCSS**: CSS processing with Tailwind and Autoprefixer

The architecture follows a separation of concerns with shared TypeScript schemas between frontend and backend, ensuring type safety across the full stack. The application supports both development and production environments with appropriate configuration for each.