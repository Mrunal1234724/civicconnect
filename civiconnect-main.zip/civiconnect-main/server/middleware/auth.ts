// src/middleware/auth.ts
import { Request, Response, NextFunction } from "express";
import admin from "firebase-admin";

// ✅ Initialize Firebase Admin SDK once
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(), // or load from env service account
  });
}

/**
 * 🔐 Middleware: Verifies Firebase ID token and attaches user info to `req.user`.
 * Use this for all protected routes.
 */
export const authMiddleware = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Unauthorized - No token provided" });
    }

    const idToken = authHeader.split(" ")[1];

    // ✅ Verify Firebase ID token using Firebase Admin SDK
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    (req as any).user = decodedToken; // attach user info to request

    next(); // Continue to next route
  } catch (error: any) {
    console.error("❌ Firebase Auth Middleware Error:", error.message);
    res.status(401).json({ message: "Invalid or expired Firebase token" });
  }
};
