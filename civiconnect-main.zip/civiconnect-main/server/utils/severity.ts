export function calculateFinalSeverity(
  userSeverity: 'low' | 'medium' | 'high',
  aiSeverity: 'low' | 'medium' | 'high',
  issueType: string
): 'low' | 'medium' | 'high' {
  const severityWeights = {
    low: 1,
    medium: 2,
    high: 3
  };

  const userWeight = severityWeights[userSeverity];
  const aiWeight = severityWeights[aiSeverity];

  // Give more weight to AI for certain critical issue types
  const aiMultiplier = issueType === 'pothole' || issueType === 'stray-dogs' ? 1.5 : 1.0;
  
  const weightedScore = (userWeight + (aiWeight * aiMultiplier)) / (1 + aiMultiplier);
  
  if (weightedScore <= 1.3) return 'low';
  if (weightedScore <= 2.3) return 'medium';
  return 'high';
}

export function getSeverityPriority(severity: 'low' | 'medium' | 'high'): number {
  switch (severity) {
    case 'high': return 3;
    case 'medium': return 2;
    case 'low': return 1;
    default: return 2;
  }
}

export function sortComplaintsBySeverity<T extends { severityFinal: string | null }>(complaints: T[]): T[] {
  return complaints.sort((a, b) => {
    const priorityA = getSeverityPriority(a.severityFinal as any || 'medium');
    const priorityB = getSeverityPriority(b.severityFinal as any || 'medium');
    return priorityB - priorityA; // High priority first
  });
}
