// src/services/auth.ts
import bcrypt from "bcrypt";
import jwt, { JwtPayload, SignOptions } from "jsonwebtoken";

/**
 * 🔐 Environment configuration
 */
const JWT_SECRET: string =
  process.env.JWT_SECRET ||
  process.env.SESSION_SECRET ||
  "fallback-secret"; // Fallback to avoid crashes in dev

const JWT_EXPIRES_IN: string | number = process.env.JWT_EXPIRES_IN || "7d"; // Default 7 days
const SALT_ROUNDS = Number(process.env.SALT_ROUNDS) || 12;

/**
 * 🧾 Token payload type
 */
export interface AuthTokenPayload {
  userId: string;
  email: string;
  role: "user" | "admin";
  isVerified: boolean;
}

/**
 * 🧂 Hash a password securely before saving
 */
export async function hashPassword(password: string): Promise<string> {
  if (!password) throw new Error("Password cannot be empty");
  try {
    return await bcrypt.hash(password, SALT_ROUNDS);
  } catch (error) {
    console.error("❌ Error hashing password:", error);
    throw new Error("Failed to hash password");
  }
}

/**
 * 🔎 Compare a plain password with its hash
 */
export async function verifyPassword(
  password: string,
  hashedPassword: string
): Promise<boolean> {
  if (!password || !hashedPassword)
    throw new Error("Password or hash missing");
  try {
    return await bcrypt.compare(password, hashedPassword);
  } catch (error) {
    console.error("❌ Error verifying password:", error);
    throw new Error("Password verification failed");
  }
}

/**
 * 🪪 Generate a signed JWT for authentication
 */
export function generateAuthToken(payload: AuthTokenPayload): string {
  try {
    // ⚙️ Explicit type cast to satisfy TS typing mismatch between runtime & types
    const options: SignOptions = { expiresIn: JWT_EXPIRES_IN as any };
    return jwt.sign(payload, JWT_SECRET, options);
  } catch (error) {
    console.error("❌ JWT generation error:", error);
    throw new Error("Failed to generate authentication token");
  }
}

/**
 * ✅ Verify and decode a JWT
 */
export function verifyAuthToken(token: string): AuthTokenPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as AuthTokenPayload;
  } catch (error) {
    console.warn(
      "⚠️ Invalid or expired token:",
      error instanceof Error ? error.message : error
    );
    return null;
  }
}

/**
 * 🆔 Generate unique tracking IDs (for complaints/reports)
 * Example: CC2025-083142
 */
export function generateTrackingId(): string {
  const prefix = "CC";
  const year = new Date().getFullYear();
  const random = Math.floor(Math.random() * 1_000_000)
    .toString()
    .padStart(6, "0");
  return `${prefix}${year}-${random}`;
}
