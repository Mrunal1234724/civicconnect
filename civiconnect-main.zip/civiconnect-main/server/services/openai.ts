import OpenAI from "openai";

/**
 * 🧩 Initialize OpenAI Client
 * - Reads API key from environment
 * - Provides a clear warning if missing
 */
const openai = new OpenAI({
  apiKey:
    process.env.OPENAI_API_KEY ||
    process.env.OPENAI_API_KEY_ENV_VAR ||
    undefined,
});

if (!process.env.OPENAI_API_KEY && !process.env.OPENAI_API_KEY_ENV_VAR) {
  console.warn("⚠️ Warning: Missing OpenAI API key — image validation will fail.");
}

/**
 * 🔍 Result type for image validation
 */
export interface ImageValidationResult {
  isRelevant: boolean;
  confidence: number;
  reason: string;
  detectedIssueType?: string;
  suggestedSeverity?: "low" | "medium" | "high";
}

/**
 * 🖼️ Validate a civic complaint image using GPT-5
 * - Checks if an image matches the described issue type
 * - Extracts confidence, reasoning, and severity
 */
export async function validateComplaintImage(
  base64Image: string,
  issueType: string,
  description: string
): Promise<ImageValidationResult> {
  if (!openai.apiKey) {
    return {
      isRelevant: false,
      confidence: 0,
      reason: "OpenAI API key missing — cannot perform image validation",
    };
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5", // ✅ Latest model as of Aug 2025
      messages: [
        {
          role: "system",
          content: `
You are an AI system that validates civic complaint images. 
Analyze if the image is relevant to the reported issue type and description.

Issue types and what to look for:
- pothole: Road damage, holes in asphalt/concrete, uneven surfaces
- waterlogging: Standing water, flooding, poor drainage, water accumulation
- stray-dogs: Stray or loose dogs in public areas, packs of dogs
- garbage-overflow: Overflowing bins, scattered trash, improper waste disposal

Respond with a JSON object containing:
{
  "isRelevant": boolean,
  "confidence": number (0–1),
  "reason": string,
  "detectedIssueType"?: string,
  "suggestedSeverity"?: "low" | "medium" | "high"
}`,
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Issue Type: ${issueType}\nDescription: ${description}\n\nPlease analyze this image and determine if it's relevant to the reported civic issue.`,
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`,
              },
            },
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 800,
    });

    const content = response.choices?.[0]?.message?.content || "{}";
    const parsed = JSON.parse(content);

    return {
      isRelevant: Boolean(parsed.isRelevant),
      confidence: Math.max(0, Math.min(1, parsed.confidence || 0)),
      reason: parsed.reason || "No reasoning provided",
      detectedIssueType: parsed.detectedIssueType,
      suggestedSeverity: parsed.suggestedSeverity,
    };
  } catch (error) {
    console.error("❌ OpenAI image validation failed:", error);
    return {
      isRelevant: false,
      confidence: 0,
      reason: "Image analysis failed due to an AI service error",
    };
  }
}

/**
 * 📊 Assess the severity of a civic issue based on:
 * - Reported issue type
 * - User description
 * - Image validation results
 */
export async function assessSeverity(
  issueType: string,
  description: string,
  userSeverity: "low" | "medium" | "high",
  imageValidationResults: ImageValidationResult[]
): Promise<{
  aiSeverity: "low" | "medium" | "high";
  finalSeverity: "low" | "medium" | "high";
  reasoning: string;
}> {
  if (!openai.apiKey) {
    return {
      aiSeverity: userSeverity,
      finalSeverity: userSeverity,
      reasoning: "OpenAI API key missing — fallback to user severity",
    };
  }

  try {
    const imageInsights = imageValidationResults
      .filter((r) => r.isRelevant)
      .map(
        (r) =>
          `Detected ${r.detectedIssueType || issueType} with ${
            r.suggestedSeverity || "unknown"
          } severity (${Math.round(r.confidence * 100)}% confidence)`
      )
      .join("; ") || "No relevant images provided.";

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `
You are an AI system that assesses the severity of civic complaints.

Severity Levels:
- LOW: Minor issues, cosmetic problems, no immediate safety risk
- MEDIUM: Moderate impact on daily life, some inconvenience
- HIGH: Safety hazards, urgent issues requiring immediate attention

Examples:
- Potholes: small = low, medium-sized = medium, large/dangerous = high
- Waterlogging: light puddles = low, major standing water = medium, flooding = high
- Stray dogs: single calm dog = low, multiple dogs/aggressive = medium, pack/attacking = high
- Garbage: small overflow = low, scattered trash = medium, blocking access = high

Respond in JSON:
{
  "aiSeverity": "low" | "medium" | "high",
  "finalSeverity": "low" | "medium" | "high",
  "reasoning": string
}`,
        },
        {
          role: "user",
          content: `Issue Type: ${issueType}
Description: ${description}
User Reported Severity: ${userSeverity}
Image Insights: ${imageInsights}

Please assess and return the appropriate severity.`,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 500,
    });

    const content = response.choices?.[0]?.message?.content || "{}";
    const parsed = JSON.parse(content);

    return {
      aiSeverity: parsed.aiSeverity || "medium",
      finalSeverity: parsed.finalSeverity || userSeverity,
      reasoning: parsed.reasoning || "Severity determined based on combined data.",
    };
  } catch (error) {
    console.error("❌ OpenAI severity assessment failed:", error);
    return {
      aiSeverity: userSeverity,
      finalSeverity: userSeverity,
      reasoning: "Technical error during AI assessment — using user severity",
    };
  }
}
