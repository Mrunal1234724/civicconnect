import { ObjectId } from "mongodb";
import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import { getDB } from "./db";
import {
  insertUserSchema,
  insertAdminSchema,
  insertComplaintSchema,
  loginSchema,
  otpVerifySchema,
} from "@shared/schema";
import {
  hashPassword,
  verifyPassword,
  generateAuthToken,
  generateTrackingId,
} from "./services/auth";
import {
  authenticateToken,
  requireRole,
  requireVerification,
  AuthenticatedRequest,
} from "./middleware/auth";

// Ensure uploads dir exists
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer config
const upload = multer({
  storage: multer.diskStorage({
    destination: uploadsDir,
    filename: (req, file, cb) => {
      const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(
        file.originalname,
      )}`;
      cb(null, uniqueName);
    },
  }),
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed") as any, false);
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // DB collections
  const usersCol = () => getDB().collection("users");
  const adminsCol = () => getDB().collection("admins");
  const otpCol = () => getDB().collection("otpVerifications");
  const complaintsCol = () => getDB().collection("complaints");

  // Health check
  app.get("/api/health", async (_req, res) =>
    res.json({ status: "ok", timestamp: new Date().toISOString() }),
  );

  //
  // --- AUTH: send OTP (no Twilio, default OTP = 123456) ---
  //
  app.post("/api/auth/send-otp", async (req, res) => {
    try {
      const { phone } = req.body;
      if (!phone || phone.length < 10) {
        return res.status(400).json({ message: "Valid phone number required" });
      }

      // 🔹 Always use the default OTP
      const otpCode = "123456";

      // Remove any previous OTP entries
      await otpCol().deleteMany({ phone });

      // Insert new OTP record (optional for tracking)
      const record = {
        phone,
        otp: otpCode, // consistent field name
        isUsed: false,
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      };

      await otpCol().insertOne(record);

      // Log OTP for debugging
      console.log(`📱 Default OTP for ${phone} is ${otpCode}`);

      return res.json({
        message: "OTP generated successfully (use 123456 to verify)",
      });
    } catch (error) {
      console.error("Send OTP error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  //
  // --- AUTH: verify OTP (default OTP = 123456) ---
  //
  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const { phone, otp } = req.body;
      if (!phone || !otp) {
        return res.status(400).json({ message: "Phone and OTP required" });
      }

      // ✅ Always accept default OTP
      if (otp === "123456") {
        return res.json({ message: "OTP verified successfully" });
      }

      // Optional DB check for stored OTPs
      const rec = await otpCol().findOne({ phone, otp, isUsed: false });
      if (!rec || (rec.expiresAt && rec.expiresAt < new Date())) {
        return res.status(400).json({ message: "Invalid or expired OTP" });
      }

      await otpCol().updateOne({ _id: rec._id }, { $set: { isUsed: true } });
      return res.json({ message: "OTP verified successfully" });
    } catch (error) {
      console.error("Verify OTP error:", error);
      return res.status(400).json({ message: "Invalid OTP data" });
    }
  });

  //
  // --- AUTH: signup ---
  //
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const userData = (() => {
        try {
          return insertUserSchema.parse(req.body);
        } catch {
          return req.body;
        }
      })();

      const existingUser = await usersCol().findOne({ email: userData.email });
      if (existingUser) return res.status(400).json({ message: "Email already registered" });

      const existingPhone = await usersCol().findOne({ phone: userData.phone });
      if (existingPhone) return res.status(400).json({ message: "Phone already registered" });

      const inputOtp = req.body.otp;

      // ✅ Accept 123456 directly
      if (inputOtp !== "123456") {
        return res.status(400).json({ message: "Invalid OTP" });
      }

      const hashedPassword = await hashPassword(userData.password);
      const newUser = {
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        password: hashedPassword,
        role: "user",
        isVerified: true,
        createdAt: new Date(),
      };

      const insertRes = await usersCol().insertOne(newUser);
      const token = generateAuthToken({
        userId: insertRes.insertedId.toString(),
        email: userData.email,
        role: "user",
        isVerified: true,
      });

      return res.status(201).json({
        message: "Account created successfully",
        token,
        user: {
          id: insertRes.insertedId.toString(),
          name: newUser.name,
          email: newUser.email,
          role: "user",
        },
      });
    } catch (error) {
      console.error("Signup error:", error);
      return res.status(400).json({ message: "Invalid signup data" });
    }
  });

  //
  // --- AUTH: login ---
  //
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      const user = await usersCol().findOne({ email });
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const valid = await verifyPassword(password, user.password);
      if (!valid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = generateAuthToken({
        userId: user._id.toString(),
        email: user.email,
        role: user.role,
        isVerified: true,
      });

      res.json({
        message: "Login successful",
        token,
        user: { id: user._id, name: user.name, email: user.email, role: user.role },
      });
    } catch (err) {
      console.error("Login error:", err);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  //
  // --- COMPLAINTS: create ---
  //
  app.post(
    "/api/complaints",
    upload.fields([{ name: "image", maxCount: 1 }, { name: "images", maxCount: 10 }]),
    async (req, res) => {
      try {
        const { userId, description, severity } = req.body;

        if (!userId || !description) {
          return res.status(400).json({ message: "User ID and description are required" });
        }

        const files = (req as any).files as { [fieldname: string]: Express.Multer.File[] };
        let chosenFile: Express.Multer.File | undefined;

        if (files?.image && files.image[0]) {
          chosenFile = files.image[0];
        } else if (files?.images && files.images[0]) {
          chosenFile = files.images[0];
        }

        if (!chosenFile) {
          return res.status(400).json({ message: "Image file is required" });
        }

        const trackingId = generateTrackingId().toString();

        const complaint = {
          userId,
          description,
          severity: severity || "Low",
          imagePath: chosenFile.filename,
          trackingId,
          createdAt: new Date(),
          status: "Pending",
        };

        const result = await complaintsCol().insertOne(complaint);

        return res.status(201).json({
          message: "Complaint submitted successfully",
          trackingId,
          id: result.insertedId.toString(),
        });
      } catch (err) {
        console.error("Complaint submission error:", err);
        return res.status(500).json({ message: "Internal server error" });
      }
    }
  );

  //
  // --- COMPLAINTS: track ---
  //
  app.get(["/api/complaints/:trackingId", "/api/complaints/track/:trackingId"], async (req, res) => {
    try {
      const trackingId = (req.params.trackingId || "").toString().trim();

      console.log("🔍 Tracking request for:", trackingId);

      const complaint = await complaintsCol().findOne({
        trackingId: { $regex: `^${trackingId}$`, $options: "i" },
      });

      if (!complaint) {
        return res.status(404).json({ message: "Complaint not found" });
      }

      return res.json({
        id: complaint._id.toString(),
        trackingId: complaint.trackingId,
        status: complaint.status,
        description: complaint.description,
        createdAt: complaint.createdAt,
        severity: complaint.severity,
      });
    } catch (err) {
      console.error("Complaint tracking error:", err);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
