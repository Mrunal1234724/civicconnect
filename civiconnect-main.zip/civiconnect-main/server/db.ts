// server/db.ts
import { MongoClient, Db } from "mongodb";
import dotenv from "dotenv";

dotenv.config();

const uri = process.env.MONGO_URI;

if (!uri) {
  throw new Error("❌ MONGO_URI must be set in .env");
}

const client = new MongoClient(uri);

let db: Db; // will hold the connected database instance

export async function connectDB(dbName = "sample_mflix") {
  try {
    await client.connect();
    db = client.db(dbName); // 👈 choose your DB name
    console.log(`✅ Connected to MongoDB, using database: ${dbName}`);
    return db;
  } catch (err) {
    console.error("❌ Failed to connect to MongoDB:", err);
    process.exit(1);
  }
}

export function getDB() {
  if (!db) {
    throw new Error("❌ Database not initialized. Call connectDB() first.");
  }
  return db;
}

export { client, db };
