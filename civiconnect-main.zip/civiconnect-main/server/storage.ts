import { ObjectId } from "mongodb";
import { getDB } from "./db";

export interface User {
  _id?: string;
  name: string;
  phone: string;
}

export interface Admin {
  _id?: string;
  name: string;
  approved: boolean;
}

export interface Complaint {
  _id?: string;
  userId: string;
  description: string;
  createdAt: Date;
}

export interface ComplaintUpdate {
  _id?: string;
  complaintId: string;
  message: string;
  createdAt: Date;
}

export interface OtpVerification {
  _id?: string;
  phone: string;
  code: string;
  createdAt: Date;
}

export class DatabaseStorage {
  // USERS
  async createUser(data: User): Promise<User> {
    const db = getDB();
    const result = await db.collection<User>("users").insertOne(data);
    return { _id: result.insertedId.toString(), ...data };
  }

  async getUserById(id: string): Promise<User | null> {
    const db = getDB();
    return await db
      .collection<User>("users")
      .findOne({ _id: new ObjectId(id) } as any);
  }

  async getUserByPhone(phone: string): Promise<User | null> {
    const db = getDB();
    return await db.collection<User>("users").findOne({ phone });
  }

  async updateUser(id: string, patch: Partial<User>): Promise<User | null> {
    const db = getDB();
    await db
      .collection<User>("users")
      .updateOne({ _id: new ObjectId(id) } as any, { $set: patch });
    return this.getUserById(id);
  }

  // ADMINS
  async createAdmin(data: Admin): Promise<Admin> {
    const db = getDB();
    const result = await db.collection<Admin>("admins").insertOne(data);
    return { _id: result.insertedId.toString(), ...data };
  }

  async getAdminById(id: string): Promise<Admin | null> {
    const db = getDB();
    return await db
      .collection<Admin>("admins")
      .findOne({ _id: new ObjectId(id) } as any);
  }

  async approveAdmin(id: string, approve: boolean): Promise<Admin | null> {
    const db = getDB();
    await db
      .collection<Admin>("admins")
      .updateOne({ _id: new ObjectId(id) } as any, { $set: { approved: approve } });
    return this.getAdminById(id);
  }

  // COMPLAINTS
  async createComplaint(data: Complaint): Promise<Complaint> {
    const db = getDB();
    const result = await db.collection<Complaint>("complaints").insertOne(data);
    return { _id: result.insertedId.toString(), ...data };
  }

  async getComplaintById(id: string): Promise<Complaint | null> {
    const db = getDB();
    return await db
      .collection<Complaint>("complaints")
      .findOne({ _id: new ObjectId(id) } as any);
  }

  async listComplaints(limit = 50): Promise<Complaint[]> {
    const db = getDB();
    return await db
      .collection<Complaint>("complaints")
      .find()
      .sort({ createdAt: -1 })
      .limit(limit)
      .toArray();
  }

  // COMPLAINT UPDATES
  async addComplaintUpdate(data: ComplaintUpdate): Promise<ComplaintUpdate> {
    const db = getDB();
    const result = await db.collection<ComplaintUpdate>("complaintUpdates").insertOne({
      ...data,
      createdAt: data.createdAt ?? new Date(),
    });
    return { _id: result.insertedId.toString(), ...data };
  }

  async getComplaintUpdates(complaintId: string): Promise<ComplaintUpdate[]> {
    const db = getDB();
    return await db
      .collection<ComplaintUpdate>("complaintUpdates")
      .find({ complaintId })
      .sort({ createdAt: -1 })
      .toArray();
  }

  // OTP (always store 123456 as default)
  async createOtp(data: OtpVerification): Promise<OtpVerification> {
    const db = getDB();

    const otpData: OtpVerification = {
      ...data,
      code: "123456", // ✅ force default OTP
      createdAt: new Date(),
    };

    const result = await db
      .collection<OtpVerification>("otpVerifications")
      .insertOne(otpData);

    return { _id: result.insertedId.toString(), ...otpData };
  }

  async getOtpById(id: string): Promise<OtpVerification | null> {
    const db = getDB();
    return await db
      .collection<OtpVerification>("otpVerifications")
      .findOne({ _id: new ObjectId(id) } as any);
  }

  async deleteOtp(id: string): Promise<void> {
    const db = getDB();
    await db
      .collection<OtpVerification>("otpVerifications")
      .deleteOne({ _id: new ObjectId(id) } as any);
  }
}

export const storage = new DatabaseStorage();
