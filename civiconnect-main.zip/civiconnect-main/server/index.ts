// server/index.ts
import "dotenv/config";
import express, { type Request, type Response, type NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { connectDB } from "./db";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Simple request logger
app.use((req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();
  const path = req.path;
  let capturedJson: any;

  const originalJson = (res as any).json?.bind(res);
  (res as any).json = function (body: any, ...args: any[]) {
    capturedJson = body;
    return originalJson ? originalJson(body, ...args) : (res as any).send(body);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    const ip = (req.headers["x-forwarded-for"] as string) || req.socket.remoteAddress || "";
    const statusCode = res.statusCode;
    const preview = capturedJson
      ? (typeof capturedJson === "string" ? capturedJson : JSON.stringify(capturedJson))
      : "";
    log(`${req.method} ${path} ${statusCode} ${duration}ms - ${ip} - ${preview}`);
  });

  next();
});

(async () => {
  try {
    // ✅ Connect to MongoDB first
    await connectDB("sample_mflix"); // change DB name if needed

    // Register routes
    const server = await registerRoutes(app);

    if (process.env.NODE_ENV !== "production") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // 🔹 Catch-all handler for unknown API routes → always return JSON
    app.use("/api/*", (req: Request, res: Response) => {
      res.status(404).json({ error: "API route not found" });
    });

    // 🔹 Global error handler → no more HTML error pages
    app.use((err: any, req: Request, res: Response, next: NextFunction) => {
      console.error("❌ Server error:", err);
      res.status(500).json({
        error: "Internal Server Error",
        details: process.env.NODE_ENV === "development" ? err.message : undefined,
      });
    });

    const port = parseInt(process.env.PORT || "5000", 10);
    server.listen({ port, host: "0.0.0.0" } as any, () => {
      log(`🚀 Server is running on http://localhost:${port}`);
    });
  } catch (err) {
    console.error("❌ Failed to start server:", err);
    process.exit(1);
  }
})();
