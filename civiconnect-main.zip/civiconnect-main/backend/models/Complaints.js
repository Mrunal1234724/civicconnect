import mongoose from "mongoose";

const complaintSchema = new mongoose.Schema({
  issueType: String,
  title: String,
  description: String,
  address: String,
  latitude: String,
  longitude: String,
  severityUser: String,
  complainantName: String,
  complainantPhone: String,
  severityFinal: String,
  status: { type: String, default: "pending" },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model("Complaint", complaintSchema);
