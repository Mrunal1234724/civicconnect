import express from "express";
import Complaint from "../models/Complaints.js";

const router = express.Router();

// ✅ Get all complaints for admin dashboard
router.get("/complaints", async (req, res) => {
  try {
    const { status, priority, issueType } = req.query;
    const query = {};

    if (status && status !== "all") query.status = status;
    if (priority && priority !== "all") query.severityUser = priority;
    if (issueType && issueType !== "all") query.issueType = issueType;

    const complaints = await Complaint.find(query).sort({ createdAt: -1 });
    res.status(200).json({ complaints });
  } catch (err) {
    console.error("Error fetching complaints:", err);
    res.status(500).json({ message: "Failed to fetch complaints" });
  }
});

export default router;
