import { MongoClient } from "mongodb";

const uri = "mongodb+srv://mitali:CivicPass2025%21@cluster0.gc88abt.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

const client = new MongoClient(uri);

async function run() {
  try {
    await client.connect();
    console.log("✅ Connected to MongoDB!");
  } catch (err) {
    console.error("❌ Failed:", err);
  } finally {
    await client.close();
  }
}

run();
